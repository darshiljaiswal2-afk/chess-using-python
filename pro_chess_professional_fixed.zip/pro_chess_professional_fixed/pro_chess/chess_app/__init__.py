"""Professional Python chess application."""
